import { describe, it, before, after } from 'node:test';
import assert from 'node:assert';
import { CognitiveBridgeService } from '../dist/services/CognitiveBridgeService.js';
import { JsonStorageAdapter } from '../dist/storage/JsonStorageAdapter.js';
import { TaskOrchestratorService } from '../dist/services/TaskOrchestratorService.js';
import { ToTService } from '../dist/services/ToTService.js';
import { v4 as uuidv4 } from 'uuid';
import fs from 'fs/promises';

describe('CognitiveBridgeService', () => {
  let bridgeService: CognitiveBridgeService;
  let taskService: TaskOrchestratorService;
  let totService: ToTService;
  let storageAdapter: JsonStorageAdapter;
  const testStoragePath = './test-bridge-state.json';

  before(async () => {
    // Clean up any existing test file
    try {
      await fs.unlink(testStoragePath);
    } catch {
      // File doesn't exist, that's fine
    }

    storageAdapter = new JsonStorageAdapter(testStoragePath);
    await storageAdapter.initialize();

    taskService = new TaskOrchestratorService(storageAdapter);
    totService = new ToTService(storageAdapter);
    bridgeService = new CognitiveBridgeService(storageAdapter, taskService, totService);

    await bridgeService.load();
    await taskService.load();
    await totService.load();
  });

  after(async () => {
    await bridgeService.shutdown();
    await taskService.shutdown();
    await totService.shutdown();
    await storageAdapter.close();

    // Clean up test file
    try {
      await fs.unlink(testStoragePath);
    } catch {
      // File doesn't exist, that's fine
    }
  });

  describe('promoteThoughtToTasks', () => {
    it('should promote a single thought to a task', async () => {
      const tree = totService.createTree({
        goal: 'Test goal',
        rootContent: 'Root thought'
      });

      const result = bridgeService.promoteThoughtToTasks({
        treeId: tree.id,
        thoughtId: tree.rootId,
        includeDescendants: false
      });

      assert.strictEqual(result.taskIds.length, 1);
      assert.strictEqual(result.thoughtsPromoted, 1);
      assert.strictEqual(result.hierarchyPreserved, true);

      const task = taskService.getTask(result.taskIds[0]);
      assert.strictEqual(task.name.includes('Root thought'), true);
      assert.strictEqual(task.metadata?.cognitive?.sourceThoughtId, tree.rootId);
    });

    it('should be idempotent - promoting same thought twice returns existing tasks', async () => {
      const tree = totService.createTree({
        goal: 'Test goal',
        rootContent: 'Root thought'
      });

      const result1 = bridgeService.promoteThoughtToTasks({
        treeId: tree.id,
        thoughtId: tree.rootId
      });

      const result2 = bridgeService.promoteThoughtToTasks({
        treeId: tree.id,
        thoughtId: tree.rootId
      });

      assert.deepStrictEqual(result1.taskIds, result2.taskIds);
      assert.strictEqual(result2.thoughtsPromoted, 0); // No new promotions
    });

    it('should promote subtree with hierarchy preserved', async () => {
      const tree = totService.createTree({
        goal: 'Test goal',
        rootContent: 'Root'
      });

      const child1 = totService.addChildThought({
        treeId: tree.id,
        parentId: tree.rootId,
        content: 'Child 1'
      });

      const child2 = totService.addChildThought({
        treeId: tree.id,
        parentId: tree.rootId,
        content: 'Child 2'
      });

      const result = bridgeService.promoteThoughtToTasks({
        treeId: tree.id,
        thoughtId: tree.rootId,
        includeDescendants: true,
        flattenHierarchy: false
      });

      assert.strictEqual(result.taskIds.length, 3);
      assert.strictEqual(result.thoughtsPromoted, 3);
      assert.strictEqual(result.hierarchyPreserved, true);
    });

    it('should attach tasks to workflow if workflowId provided', async () => {
      const tree = totService.createTree({
        goal: 'Test goal',
        rootContent: 'Root'
      });

      const workflow = taskService.createWorkflow({
        name: 'Test workflow',
        taskIds: []
      });

      const result = bridgeService.promoteThoughtToTasks({
        treeId: tree.id,
        thoughtId: tree.rootId,
        workflowId: workflow.id
      });

      const updatedWorkflow = taskService.getWorkflow(workflow.id);
      assert.strictEqual(updatedWorkflow.taskIds.length, 1);
      assert.strictEqual(updatedWorkflow.taskIds[0], result.taskIds[0]);
    });

    it('should throw error for non-existent tree', () => {
      assert.throws(() => {
        bridgeService.promoteThoughtToTasks({
          treeId: 'non-existent',
          thoughtId: 'any'
        });
      }, (err: Error) => err.message.includes('Tree with ID'));
    });

    it('should throw error for non-existent thought', () => {
      const tree = totService.createTree({
        goal: 'Test goal',
        rootContent: 'Root'
      });

      assert.throws(() => {
        bridgeService.promoteThoughtToTasks({
          treeId: tree.id,
          thoughtId: 'non-existent'
        });
      }, (err: Error) => err.message.includes('Thought'));
    });
  });

  describe('spawnTotFromTask', () => {
    it('should spawn a ToT tree from a task', async () => {
      const task = taskService.createTask({
        name: 'Test task',
        description: 'Test description'
      });

      const result = bridgeService.spawnTotFromTask({
        taskId: task.id,
        goal: 'Explore alternatives',
        rootContent: 'Initial thought'
      });

      assert.ok(result.treeId);
      assert.ok(result.rootThoughtId);

      const tree = totService.getTree(result.treeId);
      assert.strictEqual(tree.goal, 'Explore alternatives');
      assert.strictEqual(tree.metadata?.sourceTaskId, task.id);

      const updatedTask = taskService.getTask(task.id);
      assert.ok(updatedTask.metadata?.cognitive?.explorationTreeIds?.includes(result.treeId));
    });

    it('should throw error for non-existent task', () => {
      assert.throws(() => {
        bridgeService.spawnTotFromTask({
          taskId: 'non-existent',
          goal: 'Test',
          rootContent: 'Test'
        });
      }, (err: Error) => err.message.includes('Task with ID'));
    });
  });

  describe('linkThoughtToTask', () => {
    it('should create bidirectional link between thought and task', async () => {
      const tree = totService.createTree({
        goal: 'Test goal',
        rootContent: 'Root'
      });

      const task = taskService.createTask({
        name: 'Test task'
      });

      bridgeService.linkThoughtToTask({
        treeId: tree.id,
        thoughtId: tree.rootId,
        taskId: task.id,
        reason: 'Related work'
      });

      const thought = totService.getThought(tree.id, tree.rootId);
      assert.ok(thought.metadata?.cognitive?.linkedTaskIds?.includes(task.id));

      const updatedTask = taskService.getTask(task.id);
      assert.ok(updatedTask.metadata?.cognitive?.linkedThoughtIds?.includes(tree.rootId));
    });

    it('should prevent duplicate links', async () => {
      const tree = totService.createTree({
        goal: 'Test goal',
        rootContent: 'Root'
      });

      const task = taskService.createTask({
        name: 'Test task'
      });

      bridgeService.linkThoughtToTask({
        treeId: tree.id,
        thoughtId: tree.rootId,
        taskId: task.id
      });

      bridgeService.linkThoughtToTask({
        treeId: tree.id,
        thoughtId: tree.rootId,
        taskId: task.id
      });

      const thought = totService.getThought(tree.id, tree.rootId);
      const linkedTaskIds = thought.metadata?.cognitive?.linkedTaskIds || [];
      assert.strictEqual(linkedTaskIds.filter((id: string) => id === task.id).length, 1);

      const updatedTask = taskService.getTask(task.id);
      const linkedThoughtIds = updatedTask.metadata?.cognitive?.linkedThoughtIds || [];
      assert.strictEqual(linkedThoughtIds.filter((id: string) => id === tree.rootId).length, 1);
    });

    it('should set sync status to synced', async () => {
      const tree = totService.createTree({
        goal: 'Test goal',
        rootContent: 'Root'
      });

      const task = taskService.createTask({
        name: 'Test task'
      });

      bridgeService.linkThoughtToTask({
        treeId: tree.id,
        thoughtId: tree.rootId,
        taskId: task.id
      });

      const thought = totService.getThought(tree.id, tree.rootId);
      assert.strictEqual(thought.metadata?.cognitive?.syncStatus, 'synced');
      assert.ok(thought.metadata?.cognitive?.lastSyncedAt);

      const updatedTask = taskService.getTask(task.id);
      assert.strictEqual(updatedTask.metadata?.cognitive?.syncStatus, 'synced');
      assert.ok(updatedTask.metadata?.cognitive?.lastSyncedAt);
    });

    it('should add provenance chain entries', async () => {
      const tree = totService.createTree({
        goal: 'Test goal',
        rootContent: 'Root'
      });

      const task = taskService.createTask({
        name: 'Test task'
      });

      const reason = 'Inspired by this thought';
      bridgeService.linkThoughtToTask({
        treeId: tree.id,
        thoughtId: tree.rootId,
        taskId: task.id,
        reason
      });

      const thought = totService.getThought(tree.id, tree.rootId);
      const thoughtChain = thought.metadata?.cognitive?.provenanceChain || [];
      assert.ok(thoughtChain.length > 0);
      assert.strictEqual(thoughtChain[0].type, 'link');
      assert.strictEqual(thoughtChain[0].fromId, tree.rootId);
      assert.strictEqual(thoughtChain[0].toId, task.id);
      assert.strictEqual(thoughtChain[0].reason, reason);

      const updatedTask = taskService.getTask(task.id);
      const taskChain = updatedTask.metadata?.cognitive?.provenanceChain || [];
      assert.ok(taskChain.length > 0);
      assert.strictEqual(taskChain[0].type, 'link');
      assert.strictEqual(taskChain[0].fromId, task.id);
      assert.strictEqual(taskChain[0].toId, tree.rootId);
    });

    it('should throw error for non-existent tree', () => {
      const task = taskService.createTask({
        name: 'Test task'
      });

      assert.throws(() => {
        bridgeService.linkThoughtToTask({
          treeId: 'non-existent',
          thoughtId: 'any',
          taskId: task.id
        });
      }, (err: Error) => err.message.includes('Tree with ID'));
    });

    it('should throw error for non-existent thought', () => {
      const tree = totService.createTree({
        goal: 'Test goal',
        rootContent: 'Root'
      });

      const task = taskService.createTask({
        name: 'Test task'
      });

      assert.throws(() => {
        bridgeService.linkThoughtToTask({
          treeId: tree.id,
          thoughtId: 'non-existent',
          taskId: task.id
        });
      }, (err: Error) => err.message.includes('Thought'));
    });

    it('should throw error for non-existent task', () => {
      const tree = totService.createTree({
        goal: 'Test goal',
        rootContent: 'Root'
      });

      assert.throws(() => {
        bridgeService.linkThoughtToTask({
          treeId: tree.id,
          thoughtId: tree.rootId,
          taskId: 'non-existent'
        });
      }, (err: Error) => err.message.includes('Task with ID'));
    });
  });

  describe('getCognitiveProvenance', () => {
    it('should return provenance for a task', async () => {
      const tree = totService.createTree({
        goal: 'Test goal',
        rootContent: 'Root'
      });

      const result = bridgeService.promoteThoughtToTasks({
        treeId: tree.id,
        thoughtId: tree.rootId
      });

      const provenance = bridgeService.getCognitiveProvenance(
        result.taskIds[0],
        'task'
      );

      assert.strictEqual(provenance.id, result.taskIds[0]);
      assert.strictEqual(provenance.type, 'task');
      assert.ok(provenance.data);
      assert.ok(provenance.cognitiveMetadata);
    });

    it('should return provenance for a thought', async () => {
      const tree = totService.createTree({
        goal: 'Test goal',
        rootContent: 'Root'
      });

      const provenance = bridgeService.getCognitiveProvenance(
        tree.rootId,
        'thought'
      );

      assert.strictEqual(provenance.id, tree.rootId);
      assert.strictEqual(provenance.type, 'thought');
      assert.ok(provenance.data);
    });

    it('should respect maxDepth parameter', async () => {
      const tree = totService.createTree({
        goal: 'Test goal',
        rootContent: 'Root'
      });

      const child1 = totService.addChildThought({
        treeId: tree.id,
        parentId: tree.rootId,
        content: 'Child 1'
      });

      const child2 = totService.addChildThought({
        treeId: tree.id,
        parentId: child1.id,
        content: 'Child 2'
      });

      bridgeService.promoteThoughtToTasks({
        treeId: tree.id,
        thoughtId: tree.rootId,
        includeDescendants: true
      });

      const provenance = bridgeService.getCognitiveProvenance(
        tree.rootId,
        'thought',
        1
      );

      // Should limit traversal depth
      assert.ok(provenance.relatedEntries.length >= 0);
    });
  });

  describe('cognitive metadata namespace', () => {
    it('should store all bridge data under metadata.cognitive', async () => {
      const tree = totService.createTree({
        goal: 'Test goal',
        rootContent: 'Root'
      });

      bridgeService.promoteThoughtToTasks({
        treeId: tree.id,
        thoughtId: tree.rootId
      });

      const thought = totService.getThought(tree.id, tree.rootId);
      assert.ok(thought.metadata?.cognitive);
      assert.ok(thought.metadata.cognitive && (thought.metadata.cognitive as any).promotedToTaskIds);
      assert.ok(thought.metadata.cognitive && (thought.metadata.cognitive as any).promotedAt);
    });

    it('should not pollute other metadata fields', async () => {
      const tree = totService.createTree({
        goal: 'Test goal',
        rootContent: 'Root',
        metadata: { customField: 'custom value' }
      });

      bridgeService.promoteThoughtToTasks({
        treeId: tree.id,
        thoughtId: tree.rootId
      });

      const thought = totService.getThought(tree.id, tree.rootId);
      assert.strictEqual(thought.metadata?.customField, 'custom value');
      assert.ok(thought.metadata && thought.metadata.cognitive);
    });
  });

  describe('Strategy workflow management', () => {
    it('should add workflow to strategy', async () => {
      const strategy = taskService.createStrategy({
        name: 'Test strategy add workflow'
      });

      const workflow = taskService.createWorkflow({
        name: 'Test workflow',
        taskIds: []
      });

      const updatedStrategy = taskService.addWorkflowToStrategy(strategy.id, workflow.id);

      assert.ok(updatedStrategy.workflowIds.includes(workflow.id));
      assert.strictEqual(updatedStrategy.workflowIds.length, 1);
    });

    it('should prevent duplicate workflow additions to strategy', async () => {
      const strategy = taskService.createStrategy({
        name: 'Test strategy duplicate workflow'
      });

      const workflow = taskService.createWorkflow({
        name: 'Test workflow',
        taskIds: []
      });

      taskService.addWorkflowToStrategy(strategy.id, workflow.id);
      taskService.addWorkflowToStrategy(strategy.id, workflow.id);

      const updatedStrategy = taskService.getStrategy(strategy.id);
      assert.strictEqual(updatedStrategy.workflowIds.filter((id: string) => id === workflow.id).length, 1);
    });

    it('should remove workflow from strategy', async () => {
      const strategy = taskService.createStrategy({
        name: 'Test strategy remove workflow'
      });

      const workflow = taskService.createWorkflow({
        name: 'Test workflow',
        taskIds: []
      });

      taskService.addWorkflowToStrategy(strategy.id, workflow.id);
      const updatedStrategy = taskService.removeWorkflowFromStrategy(strategy.id, workflow.id);

      assert.ok(!updatedStrategy.workflowIds.includes(workflow.id));
      assert.strictEqual(updatedStrategy.workflowIds.length, 0);
    });

    it('should throw error when adding workflow to non-existent strategy', () => {
      const workflow = taskService.createWorkflow({
        name: 'Test workflow',
        taskIds: []
      });

      assert.throws(() => {
        totService.addWorkflowToStrategy('non-existent', workflow.id);
      }, (err: Error) => err.message.includes('Strategy'));
    });
  });

  describe('Strategy tree management', () => {
    it('should add tree to strategy', async () => {
      const strategy = taskService.createStrategy({
        name: 'Test strategy'
      });

      const tree = totService.createTree({
        goal: 'Test goal',
        rootContent: 'Root'
      });

      const updatedStrategy = taskService.addTreeToStrategy(strategy.id, tree.id);

      assert.ok(updatedStrategy.treeIds.includes(tree.id));
      assert.strictEqual(updatedStrategy.treeIds.length, 1);
    });

    it('should prevent duplicate tree additions to strategy', async () => {
      const strategy = taskService.createStrategy({
        name: 'Test strategy'
      });

      const tree = totService.createTree({
        goal: 'Test goal',
        rootContent: 'Root'
      });

      taskService.addTreeToStrategy(strategy.id, tree.id);
      taskService.addTreeToStrategy(strategy.id, tree.id);

      const updatedStrategy = taskService.getStrategy(strategy.id);
      assert.strictEqual(updatedStrategy.treeIds.filter((id: string) => id === tree.id).length, 1);
    });

    it('should remove tree from strategy', async () => {
      const strategy = taskService.createStrategy({
        name: 'Test strategy'
      });

      const tree = totService.createTree({
        goal: 'Test goal',
        rootContent: 'Root'
      });

      taskService.addTreeToStrategy(strategy.id, tree.id);
      const updatedStrategy = taskService.removeTreeFromStrategy(strategy.id, tree.id);

      assert.ok(!updatedStrategy.treeIds.includes(tree.id));
      assert.strictEqual(updatedStrategy.treeIds.length, 0);
    });

    it('should throw error when adding tree to non-existent strategy', () => {
      const tree = totService.createTree({
        goal: 'Test goal',
        rootContent: 'Root'
      });

      assert.throws(() => {
        taskService.addTreeToStrategy('non-existent', tree.id);
      }, (err: Error) => err.message.includes('Strategy'));
    });
  });

  describe('addIdea (renamed from addChild)', () => {
    it('should add idea using addIdea method', async () => {
      const tree = totService.createTree({
        goal: 'Test goal',
        rootContent: 'Root'
      });

      const childIdea = totService.addIdea(tree.id, tree.rootId, 'New idea');

      assert.ok(childIdea.id);
      assert.strictEqual(childIdea.content, 'New idea');
      assert.strictEqual(childIdea.parentId, tree.rootId);

      const updatedTree = totService.getTree(tree.id);
      assert.ok(updatedTree.thoughts.get(childIdea.id));
    });

    it('should support metadata in addIdea', async () => {
      const tree = totService.createTree({
        goal: 'Test goal',
        rootContent: 'Root'
      });

      const metadata = { priority: 'high' };
      const childIdea = totService.addIdea(tree.id, tree.rootId, 'New idea', metadata);

      assert.deepStrictEqual(childIdea.metadata, metadata);
    });

    it('should respect max depth when adding ideas', async () => {
      const tree = totService.createTree({
        goal: 'Test goal',
        rootContent: 'Root',
        maxDepth: 2
      });

      const child1 = totService.addIdea(tree.id, tree.rootId, 'Child 1');
      const child2 = totService.addIdea(tree.id, child1.id, 'Child 2');

      assert.throws(() => {
        totService.addIdea(tree.id, child2.id, 'Child 3');
      }, (err: Error) => err.message.includes('Maximum depth'));
    });
  });
});
